public enum OperatorType
{
    Negation,       // ¬
    Conjunction,    // ∧
    Disjunction,    // ∨
    Implication,    // →
    Biconditional   // ↔
}

